import { Routes } from '@angular/router';

const itemRoutes: Routes = [
  { path: 'addUser', loadComponent: () =>
  import('./pages/hradmin-page/additional_pages/add-page/add-page.component').then(m => m.AddPageComponent) },
  { path: 'editUser/:id',loadComponent: () =>
  import('./pages/hradmin-page/additional_pages/edit-page/edit-page.component').then(m => m.EditPageComponent) },
];


export const routes: Routes = [
  { path: 'hradmin',
    loadComponent: () =>
    import('./pages/hradmin-page/hradmin-page.component').then(m => m.HradminPageComponent),
    children: itemRoutes },
    {path: 'admin', loadComponent: () =>
    import('./pages/admin-page/admin-page.component').then(m => m.AdminPageComponent)},
    {
      path: '',
    loadComponent: () =>
    import('./pages/enter-page/enter-page.component').then(m => m.EnterPageComponent) },
  ];
