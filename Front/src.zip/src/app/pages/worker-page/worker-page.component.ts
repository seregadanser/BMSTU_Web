import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-worker-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './worker-page.component.html',
  styleUrl: './worker-page.component.css'
})
export class WorkerPageComponent {

}
