import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit-place',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './edit-place.component.html',
  styleUrl: './edit-place.component.css'
})
export class EditPlaceComponent {

}
