import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-warehouseman-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './warehouseman-page.component.html',
  styleUrl: './warehouseman-page.component.css'
})
export class WarehousemanPageComponent {

}
